<!DOCTYPE html>
<html>
<head>
	<meta charset="ISO-8859-1">
	<title>Login</title>
</head>
<body>
	<h1>Login</h1>
	<form action="session1.php" method="post">
		
		<b>Utilizador:</b><br/>
		<input type="text" name="utilizador"><br/>

		<b>Password:</b><br/>
		<input type="password" name="password">
		<br><br>
		<input type="submit" value="Entrar"><br/>

	</form>

</body>
</html>